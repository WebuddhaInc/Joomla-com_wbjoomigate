<?php

require_once('controller.php');

(new wbJoomigate_controller())->execute();
